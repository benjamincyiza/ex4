import java.util.ArrayList;

public class OlympicsWire implements Subject{
    ArrayList<Observer> observers;

    public OlympicsWire(){
        observers=new ArrayList<>();
    }


    public void broadcast(NewsItem n){
        System.out.println("New	Olympic	News	Item!!");
        notifyObservers(n);


    }

    @Override
    public void registerObserver(Observer o) {
        observers.add(o);
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o);

    }

    @Override
    public void notifyObservers(NewsItem n) {
        System.out.println(observers.size());
        for (Observer o: observers){
            o.update(n);
        }

    }
}
