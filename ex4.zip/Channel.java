public abstract class Channel implements Observer{
    NewsItem n;


    @Override
    public void update(NewsItem n){
        this.n=n;
        report();
    }
    public abstract void report();
}
