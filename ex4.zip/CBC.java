import java.sql.Array;
import java.util.ArrayList;

public class CBC extends Channel {
    ArrayList<NewsAgency> newsAgencies;

    public  CBC(ArrayList<NewsAgency> n) {
        newsAgencies=n;
        for(NewsAgency x: n){
            x.olympicsWire.registerObserver(this);
        }
    }

    public void report(){
        System.out.println("CBC	reports	"	+	n);
    }
}
