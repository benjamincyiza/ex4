public class NewsAgency {
    String name;
    OlympicsWire olympicsWire;

    public NewsAgency(String n,OlympicsWire o){
        this.name=n;
        this.olympicsWire=o;
    }
}
