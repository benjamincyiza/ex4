import java.util.ArrayList;

public class TF1 extends Channel {
    ArrayList<NewsAgency> newsAgencies;
    public TF1(ArrayList<NewsAgency> n) {
        newsAgencies=n;
        for(NewsAgency x: n){
            x.olympicsWire.registerObserver(this);
        }
    }
    public void report(){
        if(n.country.equals("France")) {
            System.out.println("TF1	reports	" + n);
        }
    }
}
