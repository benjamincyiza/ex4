import java.util.ArrayList;
import java.util.Iterator;

public class PBS extends Channel
{
    ArrayList<NewsAgency> newsAgencies;
    public PBS(ArrayList<NewsAgency> n){
        newsAgencies=n;
        for(NewsAgency x: n){
            x.olympicsWire.registerObserver(this);
        }
    }
    public void report(){
        if(n.time.equals("AM")) {
            System.out.println("PBS	reports	" + n);
        }else {
            // these statement are causing error and i can't figure out why! would you please
            // leave a comment of how i should have done?

//            for(NewsAgency x: newsAgencies){
//                x.olympicsWire.removeObserver((Observer) this);
//            }
        }
    }
}
