public interface Observer {
	public void update(NewsItem n);  //push variant
}
