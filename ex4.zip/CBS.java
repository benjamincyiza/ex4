import java.util.ArrayList;

public class CBS extends Channel{
    ArrayList<NewsAgency> newsAgencies;
    public CBS(ArrayList<NewsAgency> n) {
        newsAgencies=n;
        for(NewsAgency x: n){
            x.olympicsWire.registerObserver(this);
        }
    }
    public void report(){
        if(n.country.equals("US")) {
            System.out.println("CBS	reports	" + n);
        }
    }
}
